"""Build colab/sitesafe_code.zip: everything Colab needs, nothing large.

    python scripts/make_colab_bundle.py

Contains the sitesafe/ package, scripts/, requirements, the committed split lists (so Colab trains
on exactly the same 700 / 200 / 100 split) and the YuNet face model. Data is downloaded in Colab.
"""
from __future__ import annotations

import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def main():
    out = ROOT / "colab" / "sitesafe_code.zip"
    out.parent.mkdir(exist_ok=True)
    files = []
    for pattern in ("sitesafe/*.py", "scripts/*.py", "tests/*.py", "tests/fixtures/*.json"):
        files += sorted(ROOT.glob(pattern))
    files += [ROOT / "requirements.txt", ROOT / "requirements-train.txt", ROOT / "pyproject.toml",
              ROOT / "models" / "face_detection_yunet_2023mar.onnx"]
    for name in ("train.txt", "val.txt", "test.txt", "weatherlab.txt"):
        files.append(ROOT / "data" / "splits" / name)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for f in files:
            if f.exists():
                z.write(f, f.relative_to(ROOT).as_posix())
    print(f"wrote {out} ({out.stat().st_size / 1e6:.2f} MB, {len(files)} files)")


if __name__ == "__main__":
    main()
